const cells = document.querySelectorAll(".cell");
const message = document.getElementById("message");
const resetBtn = document.getElementById("reset");

let currentPlayer = "X";
let boardState = Array(9).fill("");

const winningPatterns = [
    [0,1,2], [3,4,5], [6,7,8],
    [0,3,6], [1,4,7], [2,5,8], 
    [0,4,8], [2,4,6]           
];

cells.forEach(cell => {
    cell.addEventListener("click", () => {
        let index = cell.getAttribute("data-index");
        if (!boardState[index]) {
            boardState[index] = currentPlayer;
            cell.textContent = currentPlayer;
            cell.classList.add("disabled");
            if (checkWin()) {
                message.textContent = `${currentPlayer} Wins!`;
                endGame();
            } else if (boardState.every(cell => cell !== "")) {
                message.textContent = "It's a Draw";
            } else {
                currentPlayer = currentPlayer === "X" ? "O" : "X";
                message.textContent = `${currentPlayer}'s Turn`;
            }
        }
    });
});

resetBtn.addEventListener("click", resetGame);

function checkWin() {
    return winningPatterns.some(pattern => {
        return pattern.every(i => boardState[i] === currentPlayer);
    });
}

function endGame() {
    cells.forEach(cell => cell.classList.add("disabled"));
}

function resetGame() {
    boardState.fill("");
    cells.forEach(cell => {
        cell.textContent = "";
        cell.classList.remove("disabled");
    });
    currentPlayer = "X";
    message.textContent = `${currentPlayer}'s Turn`;
}