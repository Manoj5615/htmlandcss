function showSelected() {
           alert("change the options");
            }