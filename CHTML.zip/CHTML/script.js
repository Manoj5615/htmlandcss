function square(number) {

 alert("The square of " + number + " is " + (number * number));
}