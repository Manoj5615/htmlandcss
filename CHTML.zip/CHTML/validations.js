        function validateForm() {
            var username = document.getElementById("username").value;
            var password = document.getElementById("password").value;
            var mobile = document.getElementById("mobile").value;

            if (password.length <= 8) {
                alert("Password must be greater than 8 characters");
               
            }

            if (mobile == "" || mobile.length != 10) {
                alert("Please enter a valid 10-digit mobile number");
                
            }
		else{ alert("Form submitted successfully!");
		    } 
        }